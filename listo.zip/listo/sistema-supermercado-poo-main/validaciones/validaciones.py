import re


def validar_username(username: str) -> (bool, str):
    """Valida que el username no sea vacío, no tenga espacios al inicio/fin,
    y contenga solo letras y guiones (sin otros símbolos ni espacios internos).
    Retorna (True, "") cuando es válido, o (False, mensaje_error).
    """
    if username is None:
        return False, "El nombre de usuario no puede ser vacío"

    if username.strip() == "":
        return False, "El nombre de usuario no puede estar vacío ni contener solo espacios"

    # No permitir espacios al inicio o final
    if username != username.strip():
        return False, "El nombre de usuario no debe tener espacios al inicio ni al final"

    # Solo letras (incluye acentos y ñ) y guiones permitidos
    if not re.fullmatch(r"[A-Za-zÁÉÍÓÚáéíóúÑñ-]+", username):
        return False, "El nombre de usuario solo puede contener letras y guiones (sin espacios ni símbolos especiales)"

    return True, ""


def validar_nombre_producto(nombre: str) -> (bool, str):
    """Valida que el nombre del producto solo contenga caracteres alfabéticos y espacios
    (sin números ni símbolos). No permite espacios al inicio/fin.
    """
    if nombre is None:
        return False, "El nombre del producto no puede ser vacío"

    if nombre.strip() == "":
        return False, "El nombre del producto no puede estar vacío ni contener solo espacios"

    if nombre != nombre.strip():
        return False, "El nombre del producto no debe tener espacios al inicio ni al final"

    # Permitir letras, tildes, ñ y espacios entre palabras
    if not re.fullmatch(r"[A-Za-zÁÉÍÓÚáéíóúÑñ ]+", nombre):
        return False, "El nombre del producto solo puede contener letras y espacios (sin números ni símbolos especiales)"

    return True, ""


def generar_codigo(productos_dict: dict) -> str:
    """Genera un código numérico autoincremental (string) basado en los códigos existentes.
    Si no hay productos devuelve '1'. Asume que los códigos existentes pueden ser strings numéricos.
    """
    max_id = 0
    for c in productos_dict.keys():
        try:
            val = int(str(c))
            if val > max_id:
                max_id = val
        except Exception:
            # Ignorar códigos no numéricos
            continue
    return str(max_id + 1)


def kilos_a_gramos_int(kilos: float) -> int:
    """Convierte kilos (float) a gramos como int. Redondea hacia abajo (int())."""
    try:
        return int(kilos * 1000)
    except Exception:
        return 0


def gramos_a_kilos_int(gramos: int) -> int:
    """Convierte gramos a kilos enteros dividiendo por 1000 y retornando int."""
    try:
        return int(gramos // 1000)
    except Exception:
        return 0
