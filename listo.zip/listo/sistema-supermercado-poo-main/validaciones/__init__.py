"""Módulo de validaciones del sistema de supermercado.

Proporciona funciones para validar datos de entrada (usuarios, productos)
y funciones auxiliares para conversiones y generación de códigos.
"""

from .validaciones import (
    validar_username,
    validar_nombre_producto,
    generar_codigo,
    kilos_a_gramos_int,
    gramos_a_kilos,
    gramos_a_kilos_int,
)

__all__ = [
    'validar_username',
    'validar_nombre_producto',
    'generar_codigo',
    'kilos_a_gramos_int',
    'gramos_a_kilos',
    'gramos_a_kilos_int',
]
