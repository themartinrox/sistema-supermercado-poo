"""
Modelo que representa una venta realizada.
Contiene la información de la transacción, incluyendo items, fecha y total.
"""
# Importa la clase datetime para trabajar con fechas y tiempos
from datetime import datetime
# Importa tipos para anotaciones estáticas (no estrictamente usadas en tiempo de ejecución)
from typing import List, Optional
# Importa la clase Producto desde el módulo hermano .producto (se asume que existe)
from .producto import Producto

class Venta:
    """
    Clase que define una transacción de venta.
    Atributos:
        id (int): Identificador único de la venta.
        items (list): Lista de diccionarios con los detalles de los productos vendidos.
        fecha (datetime): Fecha y hora de la transacción.
        total (float): Monto total de la venta.

    """
    def __init__(self, id_venta: int = None):
        # Inicializa el identificador de la venta; puede ser None si aún no tiene id.
        self.id = id_venta
        # Lista que contendrá los items agregados a la venta. Cada item es un diccionario.
        self.items = []
        # Guarda la fecha y hora de creación de la instancia (momento de la venta en este diseño).
        self.fecha = datetime.now()
        # Monto total acumulado de la venta; comienza en 0.0.
        self.total = 0.0
    
    def agregar_item(self, producto: Producto, cantidad: float):
        """
        Agrega un producto a la venta y actualiza el total.
        Calcula el subtotal basado en el precio actual del producto.
        """
        # Comentario general: se maneja un caso especial cuando el producto se vende por kilos
        # (por ejemplo, productos a granel) y la cantidad que llega está en gramos.

        # Comprueba si el objeto 'producto.unidad' tiene un atributo 'nombre' y si ese nombre es 'kilos'.
        # hasattr(obj, 'attr') evita lanzar AttributeError si 'unidad' no tiene 'nombre'.
        if hasattr(producto.unidad, 'nombre') and producto.unidad.nombre == 'kilos':
            # Si la unidad es 'kilos', se interpreta que la 'cantidad' viene en gramos.
            # Convierte la cantidad (gramos) a kilos para calcular el subtotal correctamente.
            kilos = float(cantidad) / 1000.0
            # Calcula el subtotal multiplicando el precio por los kilos.
            subtotal = producto.precio * kilos
            # 'cantidad_kilos_int' es la parte entera de kilos (por ejemplo para mostrar)
            cantidad_kilos_int = int(kilos)
            # Construye el diccionario 'item' con campos relevantes.
            item = {
                'codigo': producto.codigo,  # código identificador del producto
                'nombre': producto.nombre,  # nombre legible del producto
                'cantidad': cantidad,  # cantidad original recibida (en gramos)
                'cantidad_kilos_int': cantidad_kilos_int,  # kilos truncados a entero
                'precio_unitario': producto.precio,  # precio por kilo
                'subtotal': subtotal,  # subtotal calculado para este item
                'unidad': producto.unidad.nombre  # nombre de la unidad ('kilos')
            }
        else:
            # Caso general: producto que no se maneja por kilos.
            # Calcula el subtotal multiplicando precio por cantidad directamente.
            subtotal = producto.precio * cantidad
            # Crea el diccionario del item. Para la clave 'unidad' se intenta acceder a
            # producto.unidad.nombre si existe; si no, se deja el objeto 'unidad' tal cual.
            item = {
                'codigo': producto.codigo,
                'nombre': producto.nombre,
                'cantidad': cantidad,
                'precio_unitario': producto.precio,
                'subtotal': subtotal,
                # La expresión con hasattr evita errores si 'unidad' es una cadena o un objeto.
                'unidad': producto.unidad.nombre if hasattr(producto.unidad, 'nombre') else producto.unidad
            }

        # Añade el diccionario del item a la lista de items de la venta.
        self.items.append(item)
        # Incrementa el total acumulado de la venta con el subtotal calculado.
        self.total += subtotal
    
    def to_dict(self) -> dict:
        """Convierte la venta a diccionario para serialización JSON."""
        # Devuelve un diccionario plano con los campos necesarios. 'fecha' se convierte a string
        # usando un formato estándar para facilitar su almacenamiento y recuperación.
        return {
            'id': self.id,
            'fecha': self.fecha.strftime('%Y-%m-%d %H:%M:%S'),
            'items': self.items,
            'total': self.total
        }
    
    @staticmethod
    def from_dict(data: dict):
        """Reconstruye una venta desde un diccionario almacenado."""
        # Crea una nueva instancia de Venta recuperando el id (si existía).
        venta = Venta(data.get('id'))
        # Convierte la cadena de fecha de vuelta a un objeto datetime usando el mismo formato.
        venta.fecha = datetime.strptime(data['fecha'], '%Y-%m-%d %H:%M:%S')
        # Restaura la lista de items tal cual fue guardada.
        venta.items = data['items']
        # Restaura el total guardado.
        venta.total = data['total']
        # Retorna la instancia reconstruida.
        return venta
