"""Representa un producto en el inventario del supermercado.

Returns:
    class: Clase Producto
"""
from .categoria import Categoria
from .unidad import Unidad
# Antes se importaba una función de conversión gramos->kilos aquí. Ya no es necesaria
# porque `Producto.from_dict` y la UI manejan kilos como `float` internamente.

class Producto:
    """
    Clase que representa un producto individual en el inventario.
    Utiliza composición con las clases Categoria y Unidad.
    """
    def __init__(self, codigo: str, nombre: str, precio: float, stock, 
                 categoria: Categoria, unidad: Unidad, stock_minimo=5):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio
        # stock and stock_minimo stored as ints
        self.stock = stock
        self.categoria = categoria  # Objeto de tipo Categoria
        self.unidad = unidad        # Objeto de tipo Unidad
        self.stock_minimo = stock_minimo # Umbral para alerta de stock bajo
    
    def to_dict(self) -> dict:
        """Convierte el objeto producto a un diccionario serializable para JSON."""
        return {
            'codigo': self.codigo,
            'nombre': self.nombre,
            'precio': self.precio,
            'stock': self.stock,
            # Guardamos solo el nombre de la categoría y unidad para simplificar el JSON
            'categoria': self.categoria.nombre if isinstance(self.categoria, Categoria) else self.categoria,
            'unidad': self.unidad.nombre if isinstance(self.unidad, Unidad) else self.unidad,
            'stock_minimo': self.stock_minimo
        }
    
    @staticmethod
    def from_dict(data: dict):
        """Método de fábrica para crear una instancia de Producto desde un diccionario (JSON)."""
        unidad_data = data.get('unidad', 'unidades')
        categoria_data = data.get('categoria', 'General')
        stock = data['stock']
        stock_minimo = data.get('stock_minimo', 5)
        
        # Reconstruir objetos complejos desde strings
        unidad_obj = Unidad.from_dict(unidad_data)
        categoria_obj = Categoria.from_dict(categoria_data)
        
        # Normalizar stock y stock_minimo según la unidad
        # Para 'kilos' almacenamos la cantidad en kilos como float
        if isinstance(unidad_obj, Unidad) and unidad_obj.nombre == 'kilos':
            try:
                stock_val = float(stock)
            except Exception:
                stock_val = 0.0

            try:
                stock_min_val = float(stock_minimo)
            except Exception:
                stock_min_val = 0.0

            return Producto(
                data['codigo'],
                data['nombre'],
                data['precio'],
                stock_val,
                categoria_obj,
                unidad_obj,
                stock_min_val
            )

        # Para unidades, asegurarse que se guarden como int
        if isinstance(stock, float) and stock.is_integer():
            stock = int(stock)

        if isinstance(stock_minimo, float) and stock_minimo.is_integer():
            stock_minimo = int(stock_minimo)

        return Producto(
            data['codigo'],
            data['nombre'],
            data['precio'],
            int(stock),
            categoria_obj,
            unidad_obj,
            int(stock_minimo)
        )
    
    def tiene_stock_bajo(self) -> bool:
        """Determina si el stock actual está por debajo del mínimo permitido."""
        return self.stock <= self.stock_minimo
    
    def __str__(self) -> str:
        """Representación en cadena del producto para logs o consola."""
        alerta = " STOCK BAJO" if self.tiene_stock_bajo() else ""
        # Mostrar stock: si unidad kilos, el stock está en gramos
        if isinstance(self.unidad, Unidad) and self.unidad.nombre == 'kilos':
            # ahora almacenamos en kilos (float)
            stock_str = f"{float(self.stock):.1f} kg"
        else:
            stock_str = f"{self.stock} {self.unidad.nombre}"

        return f"{self.codigo} | {self.nombre} | ${self.precio:,.0f} | Stock: {stock_str}{alerta}"
