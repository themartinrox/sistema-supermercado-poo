"""Representa un producto en el inventario del supermercado.

Returns:
    class: Clase Producto
"""
from .categoria import Categoria
from .unidad import Unidad
from validaciones.validaciones import kilos_a_gramos_int

class Producto:
    """
    Clase que representa un producto individual en el inventario.
    Utiliza composición con las clases Categoria y Unidad.
    """
    def __init__(self, codigo: str, nombre: str, precio: float, stock, 
                 categoria: Categoria, unidad: Unidad, stock_minimo=5):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = precio
        # stock and stock_minimo stored as ints
        self.stock = stock
        self.categoria = categoria  # Objeto de tipo Categoria
        self.unidad = unidad        # Objeto de tipo Unidad
        self.stock_minimo = stock_minimo # Umbral para alerta de stock bajo
    
    def to_dict(self) -> dict:
        """Convierte el objeto producto a un diccionario serializable para JSON."""
        return {
            'codigo': self.codigo,
            'nombre': self.nombre,
            'precio': self.precio,
            'stock': self.stock,
            # Guardamos solo el nombre de la categoría y unidad para simplificar el JSON
            'categoria': self.categoria.nombre if isinstance(self.categoria, Categoria) else self.categoria,
            'unidad': self.unidad.nombre if isinstance(self.unidad, Unidad) else self.unidad,
            'stock_minimo': self.stock_minimo
        }
    
    @staticmethod
    def from_dict(data: dict):
        """Método de fábrica para crear una instancia de Producto desde un diccionario (JSON)."""
        unidad_data = data.get('unidad', 'unidades')
        categoria_data = data.get('categoria', 'General')
        stock = data['stock']
        stock_minimo = data.get('stock_minimo', 5)
        
        # Reconstruir objetos complejos desde strings
        unidad_obj = Unidad.from_dict(unidad_data)
        categoria_obj = Categoria.from_dict(categoria_data)
        
        # Normalizar stock y stock_minimo según la unidad
        # Para 'kilos' almacenamos los gramos como enteros
        if isinstance(unidad_obj, Unidad) and unidad_obj.nombre == 'kilos':
            # Si el JSON trae kilos (float/int), convertir a gramos int
            try:
                # Si el valor ya está en gramos (int), respetarlo
                if isinstance(stock, int):
                    stock_grams = stock
                else:
                    stock_grams = kilos_a_gramos_int(float(stock))
            except Exception:
                stock_grams = 0

            try:
                if isinstance(stock_minimo, int):
                    stock_minimo_grams = stock_minimo
                else:
                    stock_minimo_grams = kilos_a_gramos_int(float(stock_minimo))
            except Exception:
                stock_minimo_grams = 0

            return Producto(
                data['codigo'],
                data['nombre'],
                data['precio'],
                int(stock_grams),
                categoria_obj,
                unidad_obj,
                int(stock_minimo_grams)
            )

        # Para unidades, asegurarse que se guarden como int
        if isinstance(stock, float) and stock.is_integer():
            stock = int(stock)

        if isinstance(stock_minimo, float) and stock_minimo.is_integer():
            stock_minimo = int(stock_minimo)

        return Producto(
            data['codigo'],
            data['nombre'],
            data['precio'],
            int(stock),
            categoria_obj,
            unidad_obj,
            int(stock_minimo)
        )
    
    def tiene_stock_bajo(self) -> bool:
        """Determina si el stock actual está por debajo del mínimo permitido."""
        return self.stock <= self.stock_minimo
    
    def __str__(self) -> str:
        """Representación en cadena del producto para logs o consola."""
        alerta = " STOCK BAJO" if self.tiene_stock_bajo() else ""
        # Mostrar stock: si unidad kilos, el stock está en gramos
        if isinstance(self.unidad, Unidad) and self.unidad.nombre == 'kilos':
            stock_str = f"{self.stock} g"
        else:
            stock_str = f"{self.stock} {self.unidad.nombre}"

        return f"{self.codigo} | {self.nombre} | ${self.precio:,.0f} | Stock: {stock_str}{alerta}"
