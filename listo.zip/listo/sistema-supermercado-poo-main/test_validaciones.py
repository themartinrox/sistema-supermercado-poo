#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Script de prueba para validar las funciones agregadas."""

from validaciones import validar_username, validar_nombre_producto, generar_codigo, kilos_a_gramos_int, gramos_a_kilos_int

print("=" * 60)
print("PRUEBAS DE VALIDACIONES")
print("=" * 60)

# Test validar_username
print("\n1. VALIDACIONES DE USUARIO:")
test_usernames = [
    "juan",
    "Juan-Pérez",
    "123",
    "juan silva",
    " juan",
    "juan@",
    "",
]

for username in test_usernames:
    ok, msg = validar_username(username)
    status = "✓ VÁLIDO" if ok else "✗ INVÁLIDO"
    print(f"  {status}: '{username}' -> {msg if msg else 'Correcto'}")

# Test validar_nombre_producto
print("\n2. VALIDACIONES DE PRODUCTO:")
test_nombres = [
    "Arroz integral",
    "Leche",
    "Manzanas rojas",
    "Arroz 1kg",
    "Pollo@",
    " Pan",
    "Pan ",
    "",
]

for nombre in test_nombres:
    ok, msg = validar_nombre_producto(nombre)
    status = "✓ VÁLIDO" if ok else "✗ INVÁLIDO"
    print(f"  {status}: '{nombre}' -> {msg if msg else 'Correcto'}")

# Test generar_codigo
print("\n3. GENERACIÓN DE CÓDIGO AUTOMÁTICO:")
productos = {"1": None, "2": None, "5": None}
nuevo_codigo = generar_codigo(productos)
print(f"  Productos existentes: {list(productos.keys())}")
print(f"  Próximo código generado: {nuevo_codigo}")

# Test conversiones kilos <-> gramos
print("\n4. CONVERSIONES KILOS <-> GRAMOS:")
conversiones = [1.5, 2.0, 0.5, 10]
for kilos in conversiones:
    gramos = kilos_a_gramos_int(kilos)
    kilos_resultado = gramos_a_kilos_int(gramos)
    print(f"  {kilos} kg -> {gramos} g -> {kilos_resultado} kg")

print("\n" + "=" * 60)
print("TODAS LAS PRUEBAS COMPLETADAS")
print("=" * 60)
