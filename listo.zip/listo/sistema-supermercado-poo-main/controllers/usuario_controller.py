"""Controlador para la gestión de usuarios.

Returns:
    class: Clase UsuarioController
"""

import os
import json
from typing import Dict, Optional
from models.usuario import Usuario
from validaciones.validaciones import validar_username

class UsuarioController:
    """
    Controlador encargado de la gestión de usuarios (autenticación y registro).
    """
    
    def __init__(self, archivo_usuarios: str = 'data/usuarios.json'):
        self.archivo_usuarios = archivo_usuarios
        self.usuarios: Dict[str, Usuario] = {}
        self.cargar_usuarios()

    def cargar_usuarios(self):
        """Carga la base de datos de usuarios desde JSON."""
        if os.path.exists(self.archivo_usuarios):
            try:
                with open(self.archivo_usuarios, 'r', encoding='utf-8') as f:
                    usuarios_data = json.load(f)
                self.usuarios = {u['username']: Usuario.from_dict(u) for u in usuarios_data}
                print(f"Usuarios cargados: {len(self.usuarios)}")
            except Exception as e:
                print(f"Error al cargar usuarios: {e}")
                self._crear_usuarios_ejemplo()
        else:
            print("No se encontró archivo de usuarios. Creando usuario admin.")
            self._crear_usuarios_ejemplo()

    def guardar_usuarios(self):
        """Persiste los usuarios en el archivo JSON."""
        try:
            usuarios_list = [u.to_dict() for u in self.usuarios.values()]
            with open(self.archivo_usuarios, 'w', encoding='utf-8') as f:
                json.dump(usuarios_list, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error al guardar usuarios: {e}")

    def _crear_usuarios_ejemplo(self):
        """Genera un usuario administrador por defecto si no existe."""
        if "admin" not in self.usuarios:
            admin = Usuario("admin", "admin123", "admin")
            self.usuarios[admin.username] = admin
            self.guardar_usuarios()
            print("Usuario admin creado (user: admin, pass: admin123)")

    def registrar_usuario(self, username, password, role='comprador') -> bool:
        """
        Crea un nuevo usuario en el sistema.
        Retorna False si el nombre de usuario ya está en uso.
        """
        # Validar formato del username
        ok, msg = validar_username(username)
        if not ok:
            print(f"Registro inválido: {msg}")
            return False

        if username in self.usuarios:
            return False

        nuevo_usuario = Usuario(username, password, role)
        self.usuarios[username] = nuevo_usuario
        self.guardar_usuarios()
        return True

    def autenticar_usuario(self, username, password) -> Optional[Usuario]:
        """
        Valida las credenciales de un usuario.
        Retorna el objeto Usuario si es correcto, None en caso contrario.
        """
        usuario = self.usuarios.get(username)
        if usuario and usuario.password == password:
            return usuario
        return None
