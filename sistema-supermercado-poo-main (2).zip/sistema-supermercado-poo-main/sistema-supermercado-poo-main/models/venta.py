"""
Modelo que representa una venta realizada.
Contiene la información de la transacción, incluyendo items, fecha, total y método de pago.
"""
from datetime import datetime
from typing import List, Optional
from .producto import Producto

class Venta:
    """
    Clase que define una transacción de venta.
    Atributos:
        id (int): Identificador único de la venta (autoincremental).
        items (list): Lista de diccionarios con los detalles de los productos vendidos.
        fecha (datetime): Fecha y hora exacta de la transacción.
        total (float): Monto total de la venta (suma de subtotales).
        metodo_pago (str): Método usado para pagar ('efectivo' o 'tarjeta').
        tarjeta (dict): Información enmascarada de la tarjeta (número oculto, últimos 4 dígitos).
    """
    def __init__(self, id_venta: int = None):
        # ID único para identificar esta venta en particular
        self.id = id_venta
        # Lista de productos que se vendieron en esta transacción
        self.items = []
        # Fecha y hora del momento exacto en que se realizó la venta
        self.fecha = datetime.now()
        # Total a pagar (se calcula sumando subtotales de cada item)
        self.total = 0.0
        # Método de pago: 'efectivo' o 'tarjeta'
        self.metodo_pago: Optional[str] = None
        # Información de tarjeta si se pagó con tarjeta (número enmascarado por seguridad)
        self.tarjeta: Optional[dict] = None
    
    def agregar_item(self, producto: Producto, cantidad: float):
        """
        Agrega un producto a la venta y actualiza el total.
        Calcula el subtotal basado en el precio actual del producto.
        """
        # Calcular cuánto cuesta este item (precio × cantidad)
        subtotal = producto.precio * cantidad
        # Guardar información del item vendido
        self.items.append({
            'codigo': producto.codigo,  # Código único del producto
            'nombre': producto.nombre,  # Nombre del producto
            'cantidad': cantidad,  # Cantidad vendida
            'precio_unitario': producto.precio,  # Precio por unidad/kilo
            'subtotal': subtotal,  # Precio total de este item
            'unidad': producto.unidad.nombre if hasattr(producto.unidad, 'nombre') else producto.unidad  # Tipo de unidad
        })
        # Sumar al total de la venta
        self.total += subtotal
    
    def to_dict(self) -> dict:
        """Convierte la venta a diccionario para guardarla en JSON."""
        return {
            'id': self.id,  # ID de la venta
            'fecha': self.fecha.strftime('%Y-%m-%d %H:%M:%S'),  # Convertir fecha a texto
            'items': self.items,  # Lista de productos vendidos
            'total': self.total,  # Total de la venta
            'metodo_pago': self.metodo_pago,  # Cómo se pagó ('efectivo' o 'tarjeta')
            'tarjeta': self.tarjeta  # Detalles de la tarjeta si fue pago con tarjeta
        }
    
    @staticmethod
    def from_dict(data: dict):
        """Reconstruye una venta desde un diccionario cargado de JSON."""
        # Crear venta vacía con el ID del archivo
        venta = Venta(data.get('id'))
        # Convertir el texto de fecha de vuelta a objeto datetime
        venta.fecha = datetime.strptime(data['fecha'], '%Y-%m-%d %H:%M:%S')
        # Restaurar la lista de items vendidos
        venta.items = data['items']
        # Restaurar el total
        venta.total = data['total']
        # Restaurar método de pago (si existe)
        venta.metodo_pago = data.get('metodo_pago')
        # Restaurar información de tarjeta (si existe)
        venta.tarjeta = data.get('tarjeta')
        return venta
