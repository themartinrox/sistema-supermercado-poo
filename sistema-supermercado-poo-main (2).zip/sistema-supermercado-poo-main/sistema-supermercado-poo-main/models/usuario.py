"""
Modelo que representa un usuario del sistema.
Usa `rut` como identificador único y `nombre` como etiqueta mostrable.
"""

class Usuario:
    """
    Clase que define un usuario del sistema.
    Atributos:
        rut (str): Identificador único del usuario (formato: 7-8 dígitos + guion + dígito verificador, ej: 12345678-9).
        nombre (str): Nombre para mostrar (puede repetirse entre usuarios, solo letras y espacios).
        password (str): Contraseña del usuario.
        role (str): Rol del usuario ('admin' o 'comprador').
    """
    def __init__(self, rut: str, password: str, nombre: str = '', role: str = 'comprador'):
        # El RUT es el identificador único (no puede haber dos usuarios con el mismo RUT)
        self.rut = rut
        # Si no se proporciona nombre, usar el RUT como nombre por defecto
        self.nombre = nombre or rut
        # Contraseña sin encriptar (podría mejorarse con hashing en el futuro)
        self.password = password
        # Rol del usuario: 'admin' (acceso total) o 'comprador' (acceso limitado)
        self.role = role  # 'admin' o 'comprador'

    def to_dict(self) -> dict:
        """Convierte el objeto Usuario a diccionario para guardarlo en JSON."""
        return {
            'rut': self.rut,  # Identificador único
            'nombre': self.nombre,  # Nombre mostrable
            'password': self.password,  # Contraseña
            'role': self.role  # Rol (admin o comprador)
        }

    @staticmethod
    def from_dict(data: dict):
        """Crea una instancia de Usuario desde un diccionario JSON.

        Este método permite cargar usuarios desde archivos JSON. También soporta
        compatibilidad hacia atrás: si el JSON tiene datos antiguos con 'username'
        en lugar de 'rut', los convierte automáticamente.
        """
        # Compatibilidad: si el JSON tiene 'rut' úsalo, si sólo tiene 'username' usarlo como rut
        rut = data.get('rut') or data.get('username')
        # Usar 'nombre' si existe, sino usar 'username' (datos antiguos), sino usar el RUT
        nombre = data.get('nombre') or data.get('username') or rut
        # Obtener contraseña, si no existe usar vacío
        password = data.get('password', '')
        # Obtener rol, por defecto es 'comprador'
        role = data.get('role', 'comprador')
        # Crear y retornar el nuevo usuario
        return Usuario(rut, password, nombre, role)
