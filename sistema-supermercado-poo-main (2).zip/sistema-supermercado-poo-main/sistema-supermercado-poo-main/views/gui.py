"""Interfaz gráfica del sistema de supermercado (Vista Tkinter).

Este módulo contiene tres clases principales:
1. SupermercadoGUI - interfaz principal con tabs para admin/comprador
2. LoginWindow - pantalla de inicio de sesión
3. RegistroWindow - pantalla de registro de nuevos usuarios

Cambios principales en esta sesión:
- Autenticación con RUT en lugar de usuario
- Diálogo de pago con Efectivo/Tarjeta y visibilidad dinámica
- Validación de cantidad: kilos permite 1 decimal max, unidades solo enteros
- Columna "unidad" en carrito (muestra kilos o unidades)
- Botones admin: "Limpiar JSON" y "Resetear Inventario a 0"
- Nombre del usuario mostrado en el título (RUT - nombre)
"""

import tkinter as tk
from tkinter import ttk, messagebox
from models import Producto, Usuario
from controllers.supermercado_controller import SupermercadoController

class SupermercadoGUI:
    """
    Clase principal de la interfaz gráfica del supermercado.
    
    Maneja:
    - Las pestañas (tabs) según el rol del usuario (admin vs comprador)
    - El carrito de compras (para comprador)
    - Gestión de inventario y reportes (para admin)
    - Validaciones de entrada (RUT, cantidad, stock, etc.)
    
    El rol del usuario determina qué opciones ve:
    - ADMIN: Inventario | Ventas | Reportes | Alertas
    - COMPRADOR: Comprar | Catálogo
    """
    
    def __init__(self, root, usuario: Usuario, controller: SupermercadoController, on_logout):
        """Inicializa la GUI principal después de login exitoso.
        
        Parámetros:
            root: ventana principal de Tkinter
            usuario: objeto Usuario autenticado (contiene rut, nombre, role)
            controller: SupermercadoController (fachada de controladores)
            on_logout: callback para cerrar sesión
        """
        self.root = root
        self.usuario = usuario
        self.controller = controller
        self.on_logout = on_logout
        
        # Actualizar título con nombre y RUT del usuario logueado
        # Ejemplo: "Supermercado - Juan Pérez (12345678-9) (comprador)"
        self.root.title(f"Supermercado - {self.usuario.nombre} ({self.usuario.rut}) ({self.usuario.role})")
        self.root.geometry("1024x768")
        
        # Configurar estilo de Tkinter (tema clam es limpio y moderno)
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Contenedor principal que albergará todas las pestañas
        self.main_container = ttk.Frame(self.root)
        self.main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Crear encabezado (título, botones de sesión)
        self._setup_header()
        # Crear notebook (sistema de pestañas) con opciones según rol
        self._setup_notebook()
        
        # Diccionario para el carrito de compras: {codigo_producto: cantidad}
        self.carrito_items = {}
        
        # Evento: actualizar datos cuando el usuario cambia de pestaña
        self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_change)

    def _setup_header(self):
        """Configura el encabezado con el título y botones de sesión."""
        frame_header = ttk.Frame(self.main_container)
        frame_header.pack(fill=tk.X, pady=5)
        
        titulo_texto = "Supermercado Manager" if self.usuario.role == 'admin' else "Supermercado - Compras"
        lbl_titulo = ttk.Label(frame_header, text=titulo_texto, font=('Helvetica', 18, 'bold'))
        lbl_titulo.pack(side=tk.LEFT, pady=(0, 10))

        ttk.Button(frame_header, text="Cerrar Sesión", command=self.cerrar_sesion).pack(side=tk.RIGHT)
        ttk.Button(frame_header, text="Recargar Datos", command=self.recargar_datos).pack(side=tk.RIGHT, padx=5)
        # Botón para limpiar archivos JSON (solo para admin)
        if self.usuario.role == 'admin':
            ttk.Button(frame_header, text="Limpiar JSON", command=self.mostrar_dialogo_limpiar_json).pack(side=tk.RIGHT, padx=5)

    def _setup_notebook(self):
        """Configura las pestañas (tabs) según el rol del usuario."""
        self.notebook = ttk.Notebook(self.main_container)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        self.tab_inventario = ttk.Frame(self.notebook)
        self.tab_ventas = ttk.Frame(self.notebook)
        
        if self.usuario.role == 'admin':
            # Pestañas exclusivas de administrador
            self.tab_reportes = ttk.Frame(self.notebook)
            self.tab_alertas = ttk.Frame(self.notebook)
            
            self.notebook.add(self.tab_inventario, text="Inventario")
            self.notebook.add(self.tab_ventas, text="Ventas")
            self.notebook.add(self.tab_reportes, text="Reportes")
            self.notebook.add(self.tab_alertas, text="Alertas")
            
            self.init_inventario_admin()
            self.init_ventas()
            self.init_reportes()
            self.init_alertas()
        else: # Comprador
            # Pestañas para comprador
            self.notebook.add(self.tab_ventas, text="Comprar")
            self.notebook.add(self.tab_inventario, text="Catálogo")
            
            self.init_ventas()
            self.init_inventario_comprador()

    def recargar_datos(self):
        if messagebox.askyesno("Confirmar", "Recargar datos desde el archivo?"):
            self.controller.cargar_datos()
            self.on_tab_change() # Refresh current tab
            messagebox.showinfo("Éxito", "Datos actualizados.")

    def cerrar_sesion(self):
        self.on_logout()

    def on_tab_change(self, event=None):
        selected_tab_index = self.notebook.index(self.notebook.select())
        tab_text = self.notebook.tab(selected_tab_index, "text")
        
        if "Inventario" in tab_text or "Catálogo" in tab_text:
            if self.usuario.role == 'admin':
                self.cargar_inventario_admin()
            else:
                self.cargar_inventario_comprador()
        elif "Reportes" in tab_text:
            self.actualizar_reportes()
        elif "Alertas" in tab_text:
            self.cargar_alertas()
        elif "Ventas" in tab_text or "Comprar" in tab_text:
            self.cargar_productos_venta()

    # --- Pestaña de Inventario (Admin) ---
    def init_inventario_admin(self):
        """Inicializa la pestaña de inventario para administradores."""
        # Controles
        frame_controles = ttk.Frame(self.tab_inventario)
        frame_controles.pack(fill=tk.X, pady=5)
        ttk.Button(frame_controles, text="Nuevo Producto", command=self.mostrar_dialogo_producto).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_controles, text="Actualizar Stock", command=self.mostrar_dialogo_stock).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_controles, text="Eliminar Producto", command=self.eliminar_producto).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_controles, text="Reiniciar Productos", command=self.reiniciar_productos).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_controles, text="Resetear Inventario a 0", command=self.confirmar_resetear_inventario).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_controles, text="Crear Admin", command=self.mostrar_dialogo_crear_admin).pack(side=tk.LEFT, padx=5)
        
        # Búsqueda
        ttk.Label(frame_controles, text="Buscar:").pack(side=tk.LEFT, padx=(20, 5))
        self.entry_buscar_inv = ttk.Entry(frame_controles)
        self.entry_buscar_inv.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.entry_buscar_inv.bind('<KeyRelease>', lambda e: self.cargar_inventario_admin())
        
        # Tabla de productos
        columns = ('codigo', 'nombre', 'precio', 'stock', 'unidad', 'categoria', 'estado')
        self.tree_inv = ttk.Treeview(self.tab_inventario, columns=columns, show='headings')
        for col in columns:
            self.tree_inv.heading(col, text=col.capitalize())
        self.tree_inv.pack(fill=tk.BOTH, expand=True)
        self.cargar_inventario_admin()

    def cargar_inventario_admin(self):
        """Carga y muestra los productos en la tabla de inventario."""
        for item in self.tree_inv.get_children():
            self.tree_inv.delete(item)
        
        termino = self.entry_buscar_inv.get()
        # Filtra si hay término de búsqueda, sino muestra todo
        productos = self.controller.buscar_producto(termino) if termino else self.controller.productos.values()
        
        for p in sorted(productos, key=lambda x: x.nombre):
            estado = "BAJO" if p.tiene_stock_bajo() else "OK"
            if p.stock == 0: estado = "AGOTADO"
            self.tree_inv.insert('', tk.END, iid=p.codigo, values=(
                p.codigo, p.nombre, f"${p.precio:,.0f}", p.stock, p.unidad, p.categoria, estado
            ))

    # --- Pestaña de Inventario (Comprador) ---
    def init_inventario_comprador(self):
        # Búsqueda
        frame_controles = ttk.Frame(self.tab_inventario)
        frame_controles.pack(fill=tk.X, pady=5)
        ttk.Label(frame_controles, text="Buscar:").pack(side=tk.LEFT, padx=5)
        self.entry_buscar_cat = ttk.Entry(frame_controles)
        self.entry_buscar_cat.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.entry_buscar_cat.bind('<KeyRelease>', lambda e: self.cargar_inventario_comprador())

        # Tabla
        columns = ('nombre', 'precio', 'stock', 'categoria')
        self.tree_cat = ttk.Treeview(self.tab_inventario, columns=columns, show='headings')
        for col in columns:
            self.tree_cat.heading(col, text=col.capitalize())
        self.tree_cat.pack(fill=tk.BOTH, expand=True)
        self.cargar_inventario_comprador()

    def cargar_inventario_comprador(self):
        for item in self.tree_cat.get_children():
            self.tree_cat.delete(item)
            
        termino = self.entry_buscar_cat.get()
        productos = self.controller.buscar_producto(termino) if termino else self.controller.productos.values()

        for p in sorted(productos, key=lambda x: x.nombre):
            self.tree_cat.insert('', tk.END, values=(
                p.nombre, f"${p.precio:,.0f}", f"{p.stock} {p.unidad}", p.categoria
            ))

    # --- Pestaña de Ventas ---
    def init_ventas(self):
        """Inicializa la interfaz de ventas (POS)."""
        paned = ttk.PanedWindow(self.tab_ventas, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)
        
        # Panel de productos disponibles
        frame_prod = ttk.Labelframe(paned, text="Productos Disponibles")
        self.entry_buscar_venta = ttk.Entry(frame_prod)
        self.entry_buscar_venta.pack(fill=tk.X, padx=5, pady=5)
        self.entry_buscar_venta.bind('<KeyRelease>', lambda e: self.cargar_productos_venta())
        
        cols_prod = ('nombre', 'precio', 'stock')
        self.tree_venta_prod = ttk.Treeview(frame_prod, columns=cols_prod, show='headings', height=10)
        for col in cols_prod: self.tree_venta_prod.heading(col, text=col.capitalize())
        self.tree_venta_prod.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        frame_add = ttk.Frame(frame_prod)
        frame_add.pack(fill=tk.X, padx=5, pady=5)
        ttk.Label(frame_add, text="Cantidad:").pack(side=tk.LEFT)
        self.entry_cant_venta = ttk.Entry(frame_add, width=10)
        self.entry_cant_venta.pack(side=tk.LEFT, padx=5)
        self.entry_cant_venta.insert(0, "1")
        ttk.Button(frame_add, text="Agregar ->", command=self.agregar_al_carrito).pack(side=tk.RIGHT)
        
        # Panel de carrito de compras
        frame_cart = ttk.Labelframe(paned, text="Carrito")
        # Columnas del carrito: nombre del producto, cantidad comprada, tipo de unidad (kilos o unidades), y precio total
        cols_cart = ('nombre', 'cantidad', 'unidad', 'subtotal')
        self.tree_cart = ttk.Treeview(frame_cart, columns=cols_cart, show='headings')
        for col in cols_cart: self.tree_cart.heading(col, text=col.capitalize())
        # Ajustar el ancho de cada columna para que se vea bien
        self.tree_cart.column('nombre', width=150)
        self.tree_cart.column('cantidad', width=80)
        self.tree_cart.column('unidad', width=80)
        self.tree_cart.column('subtotal', width=100)
        self.tree_cart.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.lbl_total = ttk.Label(frame_cart, text="TOTAL: $0.00", font=('Helvetica', 14, 'bold'))
        self.lbl_total.pack(pady=5)
        
        ttk.Button(frame_cart, text="Finalizar Venta", command=self.finalizar_venta).pack(fill=tk.X, padx=5)
        ttk.Button(frame_cart, text="Limpiar", command=self.limpiar_carrito).pack(fill=tk.X, padx=5, pady=5)
        
        paned.add(frame_prod, weight=1)
        paned.add(frame_cart, weight=1)
        
        self.carrito_items = {} # Diccionario para almacenar items del carrito {codigo: cantidad}
        self.cargar_productos_venta()

    def cargar_productos_venta(self):
        """Carga los productos disponibles para la venta (stock > 0)."""
        for item in self.tree_venta_prod.get_children():
            self.tree_venta_prod.delete(item)
        
        termino = self.entry_buscar_venta.get()
        productos = self.controller.buscar_producto(termino) if termino else self.controller.obtener_productos_disponibles()
        
        for p in sorted(productos, key=lambda x: x.nombre):
            if p.stock > 0:
                self.tree_venta_prod.insert('', tk.END, iid=p.codigo, values=(p.nombre, f"${p.precio:,.0f}", p.stock))

    def agregar_al_carrito(self):
        """Agrega el producto seleccionado al carrito de compras.
        
        Valida:
        - Cantidad positiva
        - Para UNIDADES: solo números enteros (1, 2, 3... NO 1.5)
        - Para KILOS: decimales permitidos pero máximo 1 decimal (1.2 ✓, 1.25 ✗)
        - Stock disponible suficiente
        
        Si el producto ya estaba en el carrito, suma las cantidades.
        """
        selected = self.tree_venta_prod.selection()
        if not selected: 
            return
        codigo = selected[0]
        
        try:
            cantidad_str = self.entry_cant_venta.get()
            cantidad = float(cantidad_str)
            producto = self.controller.productos[codigo]
            
            # Validación 1: cantidad debe ser positiva (> 0)
            if cantidad <= 0: 
                raise ValueError("Cantidad debe ser positiva.")
            
            # Validación 2: según el tipo de unidad del producto
            # Para UNIDADES (pan, leche, botellas): solo permite números enteros
            # is_integer() retorna True si cantidad es 1.0, 2.0, 3.0 (equivalente a 1, 2, 3)
            # Retorna False si es 1.5 (decimal)
            if producto.unidad == 'unidades' and not cantidad.is_integer():
                raise ValueError("Producto se vende en unidades enteras.")
            
            # Validación 3: para KILOS permite decimales pero máximo 1 dígito después del punto
            # Ejemplo correcto: 1.2, 1.5, 2.0
            # Ejemplo incorrecto: 1.25, 1.333, 2.45
            if producto.unidad == 'kilos':
                # Si el usuario escribió un punto (ej: "1.5")
                if '.' in cantidad_str:
                    # Dividir en partes antes y después del punto
                    # "1.5".split('.') = ['1', '5']
                    decimales = len(cantidad_str.split('.')[1])
                    # Si hay más de 1 dígito después del punto, rechazar
                    if decimales > 1:
                        raise ValueError("Los kilos solo pueden tener máximo 1 decimal (ej: 1.2, 1.5)")
            
            # Validación 4: verificar que hay stock disponible
            if cantidad > producto.stock:
                raise ValueError(f"Stock insuficiente. Disponible: {producto.stock}")

            # Si todas las validaciones pasaron, agregar al carrito
            # Si el producto ya estaba en el carrito, sumar la cantidad
            # Ejemplo: si había 2 kilos y agregan 1.5 kilos más, total = 3.5 kilos
            self.carrito_items[codigo] = self.carrito_items.get(codigo, 0) + cantidad
            # Actualizar la visualización del carrito (tabla y total)
            self.actualizar_carrito_y_total()

        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def actualizar_carrito_y_total(self):
        """Refresca la visualización del carrito y recalcula el total a pagar.
        
        Operaciones:
        1. Limpia la tabla de carrito
        2. Para cada item en carrito_items:
           - Busca el producto en el inventario
           - Calcula subtotal (precio × cantidad)
           - Inserta fila en tabla mostrando: nombre, cantidad, unidad (kilos/unidades), subtotal
        3. Suma todos los subtotales para obtener el TOTAL
        4. Actualiza el label de total a pagar con formato de dinero
        """
        # Limpiar todos los items mostrados en la tabla del carrito
        for item in self.tree_cart.get_children():
            self.tree_cart.delete(item)
        
        total = 0  # Acumulador del total
        # Recorrer cada producto que el cliente agregó al carrito
        # carrito_items es un diccionario: {codigo_producto: cantidad}
        for codigo, cantidad in self.carrito_items.items():
            producto = self.controller.productos[codigo]
            # Calcular el subtotal para este producto: precio_unitario × cantidad
            subtotal = producto.precio * cantidad
            # Sumar al total general
            total += subtotal
            # Insertar una fila en la tabla mostrando:
            # - nombre: nombre del producto
            # - cantidad: cantidad comprada (puede ser 1.5 si es kilos)
            # - unidad: "kilos" o "unidades" (tipo de medida del producto)
            # - subtotal: precio formateado como dinero (ej: "$1,500")
            self.tree_cart.insert('', tk.END, values=(
                producto.nombre, 
                cantidad, 
                producto.unidad, 
                f"${subtotal:,.0f}"
            ))
        
        # Actualizar el label de total a pagar con formato de dinero
        # Ejemplo: "TOTAL: $45,000"
        self.lbl_total.config(text=f"TOTAL: ${total:,.0f}")

    def limpiar_carrito(self):
        """Vacía el carrito de compras."""
        self.carrito_items.clear()
        self.actualizar_carrito_y_total()

    def finalizar_venta(self):
        """Procesa la venta final con selección de método de pago.
        
        Flujo:
        1. Valida que el carrito no esté vacío
        2. Abre diálogo modal para elegir: Efectivo o Tarjeta
        3. Si elige Tarjeta, muestra/oculta campos dinámicamente (número 12 dígitos, PIN 4 dígitos)
        4. Valida campos según método elegido
        5. Enmascare número de tarjeta antes de guardar
        6. Llama a realizar_venta en el controlador
        7. Actualiza interfaces si es exitosa
        """
        # Verificar que hay items en el carrito
        if not self.carrito_items: 
            return
        # Convertir carrito_items {codigo: cantidad} a lista de tuplas para el controlador
        items_venta = list(self.carrito_items.items())

        # Crear diálogo modal (ventana secundaria que bloquea la principal)
        top = tk.Toplevel(self.root)
        top.title("Método de Pago")
        # transient() hace que la ventana flote sobre la principal
        # grab_set() hace que sea modal (bloquea la ventana principal)
        top.transient(self.root)
        top.grab_set()
        
        # Mostrar el total a pagar (ej: "TOTAL: $45,000")
        ttk.Label(top, text=f"Total a pagar: {self.lbl_total['text']}", font=('Helvetica', 12, 'bold')).pack(padx=12, pady=10)

        # === SELECCIÓN DE MÉTODO DE PAGO ===
        metodo_var = tk.StringVar(value='efectivo')  # Por defecto: efectivo
        frame_met = ttk.Frame(top)
        frame_met.pack(padx=12, pady=10, fill=tk.X)
        # Radio button 1: Efectivo (sin campos adicionales)
        ttk.Radiobutton(frame_met, text='Efectivo', variable=metodo_var, value='efectivo').pack(side=tk.LEFT, padx=5)
        # Radio button 2: Tarjeta (requiere número y PIN)
        ttk.Radiobutton(frame_met, text='Tarjeta', variable=metodo_var, value='tarjeta').pack(side=tk.LEFT, padx=5)

        # === CAMPOS DE TARJETA (mostrados solo si selecciona Tarjeta) ===
        # Frame LabelFrame que contiene los campos de tarjeta
        frame_tar = ttk.LabelFrame(top, text="Datos de la Tarjeta", padding=10)
        frame_tar.pack(padx=12, pady=5, fill=tk.X)
        # pack_forget() oculta el frame sin eliminarlo (permite pack() después)
        frame_tar.pack_forget()  # Ocultado por defecto hasta que seleccione tarjeta

        # Campo 1: Número de tarjeta (12 dígitos)
        ttk.Label(frame_tar, text='Número de Tarjeta (12 dígitos):').pack(anchor=tk.W)
        entry_tarjeta = ttk.Entry(frame_tar)
        entry_tarjeta.pack(fill=tk.X, pady=2)
        
        # Campo 2: PIN (4 dígitos, mostrado como *)
        ttk.Label(frame_tar, text='PIN (4 dígitos):').pack(anchor=tk.W)
        entry_pin = ttk.Entry(frame_tar, show='*')  # show='*' oculta los caracteres
        entry_pin.pack(fill=tk.X, pady=2)

        def on_metodo_change(*args):
            """Callback ejecutado cuando cambia la selección de método (efectivo/tarjeta).
            
            Visibilidad dinámica:
            - Si selecciona TARJETA: mostrar frame_tar (pack) y enfocar en número
            - Si selecciona EFECTIVO: ocultar frame_tar (pack_forget) y limpiar campos
            """
            # Si selecciona tarjeta, mostrar los campos para ingresar número y PIN
            if metodo_var.get() == 'tarjeta':
                frame_tar.pack(padx=12, pady=5, fill=tk.X)  # Mostrar
                entry_tarjeta.focus()  # Poner cursor en campo de número
            else:
                # Si selecciona efectivo, ocultar y limpiar los campos de tarjeta
                frame_tar.pack_forget()  # Ocultar sin eliminar
                entry_tarjeta.delete(0, tk.END)  # Limpiar número
                entry_pin.delete(0, tk.END)  # Limpiar PIN

        # Vincular el cambio de metodo_var con la función on_metodo_change
        # trace_add('write', ...) ejecuta la función cuando cambia el StringVar
        metodo_var.trace_add('write', on_metodo_change)

        def aceptar():
            """Procesa la venta después de validar los datos de pago."""
            metodo = metodo_var.get()
            tarjeta_info = None
            
            # Si el método es TARJETA, validar y procesar datos
            if metodo == 'tarjeta':
                num = entry_tarjeta.get().strip()
                pin = entry_pin.get().strip()
                
                # Validación 1: ambos campos son obligatorios
                if not num or not pin:
                    messagebox.showerror('Error', 'Complete número de tarjeta y PIN')
                    return
                
                # Validación 2: número debe ser exactamente 12 dígitos numéricos
                if len(num) != 12 or not num.isdigit():
                    messagebox.showerror('Error', 'El número de tarjeta debe tener 12 dígitos')
                    return
                
                # Validación 3: PIN debe ser exactamente 4 dígitos numéricos
                if len(pin) != 4 or not pin.isdigit():
                    messagebox.showerror('Error', 'La contraseña/PIN debe tener 4 dígitos')
                    return
                
                # Enmascarar número de tarjeta para guardado seguro
                # Formato: primeros 4 dígitos + **** + últimos 4 dígitos
                # Ejemplo: 1234****5678
                masked = f"{num[:4]}{'*'*4}{num[-4:]}"
                # Guardar información de tarjeta enmascarada
                tarjeta_info = {'numero_masked': masked, 'ultimo4': num[-4:]}

            # Pedir confirmación final antes de procesar la venta
            if not messagebox.askyesno('Confirmar', f'Procesar venta por {self.lbl_total["text"]} usando {metodo.capitalize()}?'):
                return

            # Llamar al controlador para realizar la venta
            # Parámetros:
            # - items_venta: lista de (codigo, cantidad)
            # - metodo_pago: "efectivo" o "tarjeta"
            # - tarjeta: diccionario con datos enmascarados (None si es efectivo)
            venta = self.controller.realizar_venta(items_venta, metodo_pago=metodo, tarjeta=tarjeta_info)
            
            if venta:
                # Venta exitosa: mostrar confirmación con detalles
                messagebox.showinfo(
                    'Éxito', 
                    f'Venta realizada!\n'
                    f'ID: {venta.id}\n'
                    f'Total: ${venta.total:,.0f}\n'
                    f'Método: {metodo.capitalize()}'
                )
                # Cerrar diálogo de pago
                top.destroy()
                # Vaciar carrito y recargar productos disponibles
                self.limpiar_carrito()
                self.cargar_productos_venta()
            else:
                # Venta fallida (probablemente por stock insuficiente)
                messagebox.showerror('Error', 'No se pudo procesar la venta. Verifique el stock.')

        def cancelar():
            """Cerrar el diálogo sin procesar la venta."""
            top.destroy()

        # Crear frame para los botones (Aceptar y Cancelar)
        btn_frame = ttk.Frame(top)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text='Aceptar', command=aceptar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text='Cancelar', command=cancelar).pack(side=tk.LEFT, padx=5)

    # --- Pestaña de Reportes ---
    def init_reportes(self):
        """Inicializa la vista de reportes y estadísticas."""
        self.frame_stats = ttk.Frame(self.tab_reportes, padding=20)
        self.frame_stats.pack(fill=tk.BOTH, expand=True)
        
        self.lbl_stats_prod = ttk.Label(self.frame_stats, font=('Helvetica', 12))
        self.lbl_stats_prod.pack(anchor=tk.W, pady=5)
        
        self.lbl_stats_ventas = ttk.Label(self.frame_stats, font=('Helvetica', 12))
        self.lbl_stats_ventas.pack(anchor=tk.W, pady=5)
        
        self.lbl_stats_ingresos = ttk.Label(self.frame_stats, font=('Helvetica', 12))
        self.lbl_stats_ingresos.pack(anchor=tk.W, pady=5)
        
        ttk.Separator(self.frame_stats).pack(fill=tk.X, pady=20)
        ttk.Label(self.frame_stats, text="Últimas Ventas:", font=('Helvetica', 12, 'bold')).pack(anchor=tk.W)
        
        self.txt_log = tk.Text(self.frame_stats, height=15, state='disabled')
        self.txt_log.pack(fill=tk.BOTH, expand=True, pady=10)
        self.actualizar_reportes()

    def actualizar_reportes(self):
        """Calcula y muestra las estadísticas actualizadas."""
        stats = self.controller.obtener_estadisticas()
        self.lbl_stats_prod.config(text=f"Total Productos: {stats['total_productos']} (Valor: ${stats['valor_inventario']:,.0f})")
        self.lbl_stats_ventas.config(text=f"Total Ventas: {stats['total_ventas']}")
        self.lbl_stats_ingresos.config(text=f"Ingresos Totales: ${stats['ingresos_totales']:,.0f}")
        
        self.txt_log.config(state='normal')
        self.txt_log.delete(1.0, tk.END)
        for venta in reversed(self.controller.ventas[-10:]):
            id_venta = venta.get('id', 'N/A')
            self.txt_log.insert(tk.END, f"ID {id_venta} | Fecha {venta['fecha']} | Total: ${venta['total']:,.0f} | Items: {len(venta['items'])}\n")
        self.txt_log.config(state='disabled')

    # --- Pestaña de Alertas ---
    def init_alertas(self):
        """Inicializa la vista de alertas de stock bajo."""
        ttk.Label(self.tab_alertas, text="Productos con Stock Crítico", font=('Helvetica', 14, 'bold'), foreground='red').pack(pady=10)
        cols = ('codigo', 'nombre', 'stock', 'minimo')
        self.tree_alertas = ttk.Treeview(self.tab_alertas, columns=cols, show='headings')
        for col in cols: self.tree_alertas.heading(col, text=col.capitalize())
        self.tree_alertas.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        ttk.Button(self.tab_alertas, text="Actualizar", command=self.cargar_alertas).pack(pady=10)
        self.cargar_alertas()

    def cargar_alertas(self):
        """Filtra y muestra solo los productos con stock bajo."""
        for item in self.tree_alertas.get_children():
            self.tree_alertas.delete(item)
        for p in self.controller.obtener_productos_stock_bajo():
            self.tree_alertas.insert('', tk.END, values=(p.codigo, p.nombre, p.stock, p.stock_minimo))

    # --- Diálogos ---
    def mostrar_dialogo_producto(self):
        """Muestra formulario para agregar producto en la misma ventana"""
        # Ocultar la tabla temporalmente
        self.tree_inv.pack_forget()
        
        # Crear frame para el formulario
        form_frame = ttk.Frame(self.tab_inventario)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        ttk.Label(form_frame, text="Nuevo Producto", font=('Helvetica', 14, 'bold')).pack(pady=10)
        
        # Campos del formulario
        campos_frame = ttk.Frame(form_frame)
        campos_frame.pack(fill=tk.BOTH, expand=True)
        
        entries = {}
        
        # Código
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Código:", width=25).pack(side=tk.LEFT)
        entry_codigo = ttk.Entry(row_frame)
        entry_codigo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['codigo'] = entry_codigo
        
        # Nombre
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Nombre:", width=25).pack(side=tk.LEFT)
        entry_nombre = ttk.Entry(row_frame)
        entry_nombre.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['nombre'] = entry_nombre
        
        # Precio
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Precio (CLP):", width=25).pack(side=tk.LEFT)
        entry_precio = ttk.Entry(row_frame)
        entry_precio.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['precio'] = entry_precio
        
        # Stock
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Stock Inicial:", width=25).pack(side=tk.LEFT)
        entry_stock = ttk.Entry(row_frame)
        entry_stock.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['stock'] = entry_stock
        
        # Categoría (Combobox)
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Categoría:", width=25).pack(side=tk.LEFT)
        combo_categoria = ttk.Combobox(row_frame, state='readonly', values=[
            "Abarrotes", "Lácteos", "Panadería", "Frutas", "Verduras", 
            "Carnes", "Bebidas", "Limpieza", "Snacks", "Congelados"
        ])
        combo_categoria.pack(side=tk.LEFT, fill=tk.X, expand=True)
        combo_categoria.set("Abarrotes")  # Valor por defecto
        entries['categoria'] = combo_categoria
        
        # Unidad (Combobox)
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Unidad:", width=25).pack(side=tk.LEFT)
        combo_unidad = ttk.Combobox(row_frame, state='readonly', values=["unidades", "kilos"])
        combo_unidad.pack(side=tk.LEFT, fill=tk.X, expand=True)
        combo_unidad.set("unidades")  # Valor por defecto
        entries['unidad'] = combo_unidad
        
        # Stock Mínimo
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Stock Mínimo:", width=25).pack(side=tk.LEFT)
        entry_stock_minimo = ttk.Entry(row_frame)
        entry_stock_minimo.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entry_stock_minimo.insert(0, "5")
        entries['stock_minimo'] = entry_stock_minimo
        
        def guardar():
            try:
                codigo = entries['codigo'].get().strip()
                nombre = entries['nombre'].get().strip()
                categoria = entries['categoria'].get().strip()
                unidad = entries['unidad'].get().strip().lower()
                
                if not codigo or not nombre or not categoria:
                    messagebox.showwarning("Error", "Todos los campos de texto son obligatorios")
                    return

                if unidad not in ['unidades', 'kilos']:
                    messagebox.showwarning("Error", "La unidad debe ser 'unidades' o 'kilos'")
                    return

                precio = int(entries['precio'].get())
                if precio < 0:
                    raise ValueError("El precio no puede ser negativo")

                stock = float(entries['stock'].get())
                if stock < 0:
                    raise ValueError("El stock no puede ser negativo")
                if unidad == 'unidades' and not stock.is_integer():
                    messagebox.showerror("Error", "Para 'unidades', el stock debe ser un número entero")
                    return

                stock_min = float(entries['stock_minimo'].get())
                if stock_min < 0:
                    raise ValueError("El stock mínimo no puede ser negativo")
                if unidad == 'unidades' and not stock_min.is_integer():
                    messagebox.showerror("Error", "Para 'unidades', el stock mínimo debe ser entero")
                    return

                p = Producto(codigo, nombre, precio, stock, categoria, unidad, stock_min)
                
                if self.controller.agregar_producto(p):
                    messagebox.showinfo("Éxito", "Producto agregado correctamente")
                    cancelar()
                    self.cargar_inventario_admin()
                else:
                    messagebox.showerror("Error", "El código ya existe")
            except ValueError as e:
                messagebox.showerror("Error", f"Valores inválidos: {str(e)}")
        
        def cancelar():
            form_frame.destroy()
            self.tree_inv.pack(fill=tk.BOTH, expand=True)
        
        # Botones
        btn_frame = ttk.Frame(form_frame)
        btn_frame.pack(fill=tk.X, pady=20)
        ttk.Button(btn_frame, text="Guardar", command=guardar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancelar", command=cancelar).pack(side=tk.LEFT, padx=5)

    def mostrar_dialogo_stock(self):
        """Muestra formulario para actualizar stock en la misma ventana"""
        selected = self.tree_inv.selection()
        if not selected:
            messagebox.showwarning("Aviso", "Seleccione un producto de la lista")
            return
            
        codigo = selected[0]
        producto = self.controller.productos[codigo]
        
        # Ocultar la tabla temporalmente
        self.tree_inv.pack_forget()
        
        # Crear frame para el formulario
        form_frame = ttk.Frame(self.tab_inventario)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        ttk.Label(form_frame, text=f"Actualizar Stock", font=('Helvetica', 14, 'bold')).pack(pady=10)
        ttk.Label(form_frame, text=f"Producto: {producto.nombre}", font=('Helvetica', 12)).pack(pady=5)
        ttk.Label(form_frame, text=f"Stock actual: {producto.stock} {producto.unidad}", font=('Helvetica', 10)).pack(pady=5)
        
        # Frame para opciones
        opciones_frame = ttk.Frame(form_frame)
        opciones_frame.pack(pady=20)
        
        tipo_var = tk.StringVar(value="agregar")
        ttk.Radiobutton(opciones_frame, text="Agregar", variable=tipo_var, value="agregar").pack(side=tk.LEFT, padx=10)
        ttk.Radiobutton(opciones_frame, text="Restar", variable=tipo_var, value="restar").pack(side=tk.LEFT, padx=10)
        
        # Campo de cantidad
        ttk.Label(form_frame, text="Cantidad:").pack(pady=5)
        entry_cant = ttk.Entry(form_frame, width=20)
        entry_cant.pack(pady=5)
        entry_cant.focus()
        
        def actualizar():
            try:
                cant = float(entry_cant.get())
                if cant <= 0:
                    messagebox.showerror("Error", "La cantidad debe ser mayor a 0")
                    return

                if producto.unidad == 'unidades' and not cant.is_integer():
                    messagebox.showerror("Error", f"El producto se maneja por unidades.\nNo se admiten decimales.")
                    return

                if self.controller.actualizar_stock(codigo, cant, tipo_var.get()):
                    prod = self.controller.productos[codigo]
                    if prod.tiene_stock_bajo():
                        messagebox.showwarning("Alerta de Stock", f"El producto '{prod.nombre}' tiene stock bajo: {prod.stock} {prod.unidad}")
                    else:
                        messagebox.showinfo("Éxito", "Stock actualizado correctamente")
                    
                    cancelar()
                    self.cargar_inventario_admin()
                else:
                    messagebox.showerror("Error", "No se pudo actualizar (Stock insuficiente?)")
            except ValueError:
                messagebox.showerror("Error", "Cantidad inválida")
        
        def cancelar():
            form_frame.destroy()
            self.tree_inv.pack(fill=tk.BOTH, expand=True)
        
        # Botones
        btn_frame = ttk.Frame(form_frame)
        btn_frame.pack(fill=tk.X, pady=20)
        ttk.Button(btn_frame, text="Actualizar", command=actualizar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancelar", command=cancelar).pack(side=tk.LEFT, padx=5)
    
    def eliminar_producto(self):
        """Elimina el producto seleccionado"""
        selected = self.tree_inv.selection()
        if not selected:
            messagebox.showwarning("Aviso", "Seleccione un producto de la lista")
            return
            
        codigo = selected[0]
        producto = self.controller.productos[codigo]
        
        if messagebox.askyesno("Confirmar Eliminación", 
                              f"¿Está seguro de eliminar el producto '{producto.nombre}'?\n\nEsta acción no se puede deshacer."):
            if self.controller.eliminar_producto(codigo):
                messagebox.showinfo("Éxito", f"Producto '{producto.nombre}' eliminado correctamente")
                self.cargar_inventario_admin()
            else:
                messagebox.showerror("Error", "No se pudo eliminar el producto")
    
    def reiniciar_productos(self):
        """Reinicia todos los productos a los valores por defecto"""
        if messagebox.askyesno("Confirmar Reinicio", 
                              "¿Está seguro de reiniciar todos los productos a los valores por defecto?\n\n"
                              "Esto eliminará todos los productos actuales y los reemplazará con los productos de ejemplo.\n"
                              "Las ventas y usuarios NO se verán afectados.\n\n"
                              "Esta acción no se puede deshacer."):
            if self.controller.reiniciar_productos():
                messagebox.showinfo("Éxito", "Productos reiniciados correctamente")
                self.cargar_inventario_admin()
            else:
                messagebox.showerror("Error", "No se pudo reiniciar los productos")

    def mostrar_dialogo_crear_admin(self):
        """Muestra formulario para crear un nuevo administrador"""
        # Ocultar la tabla temporalmente
        self.tree_inv.pack_forget()
        
        # Crear frame para el formulario
        form_frame = ttk.Frame(self.tab_inventario)
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        ttk.Label(form_frame, text="Nuevo Administrador", font=('Helvetica', 14, 'bold')).pack(pady=10)
        
        # Campos del formulario
        campos_frame = ttk.Frame(form_frame)
        campos_frame.pack(fill=tk.BOTH, expand=True)
        
        entries = {}
        
        # RUT
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="RUT:", width=25).pack(side=tk.LEFT)
        entry_rut = ttk.Entry(row_frame)
        entry_rut.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['rut'] = entry_rut

        # Nombre para mostrar
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Nombre:", width=25).pack(side=tk.LEFT)
        entry_nombre_admin = ttk.Entry(row_frame)
        entry_nombre_admin.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['nombre'] = entry_nombre_admin
        
        # Contraseña
        row_frame = ttk.Frame(campos_frame)
        row_frame.pack(fill=tk.X, pady=5)
        ttk.Label(row_frame, text="Contraseña:", width=25).pack(side=tk.LEFT)
        entry_pass = ttk.Entry(row_frame, show="*")
        entry_pass.pack(side=tk.LEFT, fill=tk.X, expand=True)
        entries['password'] = entry_pass
        
        def guardar():
            rut = entries['rut'].get().strip()
            nombre = entries['nombre'].get().strip()
            password = entries['password'].get().strip()

            if not rut or not password:
                messagebox.showwarning("Error", "RUT y contraseña son obligatorios")
                return

            try:
                ok = self.controller.registrar_usuario(rut, password, nombre, 'admin')
                if ok:
                    messagebox.showinfo("Éxito", f"Administrador '{rut}' creado correctamente")
                    cancelar()
                else:
                    messagebox.showerror("Error", "El RUT ya existe")
            except ValueError as ve:
                messagebox.showerror("Error de validación", str(ve))
        
        def cancelar():
            form_frame.destroy()
            self.tree_inv.pack(fill=tk.BOTH, expand=True)
        
        # Botones
        btn_frame = ttk.Frame(form_frame)
        btn_frame.pack(fill=tk.X, pady=20)
        ttk.Button(btn_frame, text="Crear Admin", command=guardar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Cancelar", command=cancelar).pack(side=tk.LEFT, padx=5)

    def confirmar_resetear_inventario(self):
        """Pide confirmación al admin y ejecuta el reset a 0 del inventario.
        
        Operación:
        - Pone el stock de TODOS los productos a 0
        - NO elimina los productos (mantiene códigos, nombres, categorías)
        - Útil para auditoría de inventario o inicio de nuevo período
        """
        # Mostrar diálogo de confirmación
        if not messagebox.askyesno(
            'Confirmar', 
            '¿Desea poner el stock de TODOS los productos en 0?\n'
            'Esta acción sobrescribirá el inventario actual.'
        ):
            return  # Usuario canceló

        # Llamar al controlador para resetear inventario
        ok = self.controller.resetear_inventario_cero()
        if ok:
            messagebox.showinfo('Éxito', 'Inventario reseteado a 0 correctamente')
            # Recargar vistas para mostrar cambios
            self.cargar_inventario_admin()
            self.cargar_productos_venta()
        else:
            messagebox.showerror('Error', 'No se pudo resetear el inventario')

    def mostrar_dialogo_limpiar_json(self):
        """Muestra diálogo para seleccionar y limpiar los JSON de productos/usuarios/ventas."""
        top = tk.Toplevel(self.root)
        top.title("Limpiar JSON")
        top.transient(self.root)
        top.grab_set()

        ttk.Label(top, text="Seleccione los archivos a limpiar:", font=('Helvetica', 12, 'bold')).pack(padx=12, pady=8)

        var_prod = tk.BooleanVar(value=False)
        var_users = tk.BooleanVar(value=False)
        var_ventas = tk.BooleanVar(value=False)

        ttk.Checkbutton(top, text='Productos (data/productos.json)', variable=var_prod).pack(anchor=tk.W, padx=12)
        ttk.Checkbutton(top, text='Usuarios (data/usuarios.json)', variable=var_users).pack(anchor=tk.W, padx=12)
        ttk.Checkbutton(top, text='Ventas (data/ventas.json)', variable=var_ventas).pack(anchor=tk.W, padx=12)

        def aceptar():
            seleccion = []
            if var_prod.get(): seleccion.append('productos')
            if var_users.get(): seleccion.append('usuarios')
            if var_ventas.get(): seleccion.append('ventas')

            if not seleccion:
                messagebox.showwarning('Aviso', 'Seleccione al menos un archivo para limpiar')
                return

            if not messagebox.askyesno('Confirmar', f"¿Limpiar los siguientes archivos? {', '.join(seleccion)}\nEsta acción no se puede deshacer."):
                return

            errores = []
            if var_prod.get():
                if not self.controller.limpiar_productos(): errores.append('productos')
            if var_users.get():
                # Mantener admin por defecto después de limpiar
                if not self.controller.limpiar_usuarios(keep_admin=True): errores.append('usuarios')
            if var_ventas.get():
                if not self.controller.limpiar_ventas(): errores.append('ventas')

            if errores:
                messagebox.showerror('Error', f"Ocurrió un error limpiando: {', '.join(errores)}")
            else:
                messagebox.showinfo('Éxito', 'Archivos limpiados correctamente')
                self.controller.cargar_datos()
                self.on_tab_change()
                top.destroy()

        def cancelar():
            top.destroy()

        btn_frame = ttk.Frame(top)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text='Aceptar', command=aceptar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text='Cancelar', command=cancelar).pack(side=tk.LEFT, padx=5)

class LoginWindow:
    def __init__(self, root, controller: SupermercadoController, on_login_success, on_show_registro):
        self.root = root
        self.controller = controller
        self.on_login_success = on_login_success
        self.on_show_registro = on_show_registro
        
        self.frame = ttk.Frame(root, padding="20")
        self.frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(self.frame, text="Iniciar Sesión", font=('Helvetica', 16, 'bold')).pack(pady=20)
        
        ttk.Label(self.frame, text="RUT:").pack(anchor=tk.W)
        self.entry_user = ttk.Entry(self.frame)
        self.entry_user.pack(fill=tk.X, pady=5)
        
        ttk.Label(self.frame, text="Contraseña:").pack(anchor=tk.W)
        self.entry_pass = ttk.Entry(self.frame, show="*")
        self.entry_pass.pack(fill=tk.X, pady=5)
        
        ttk.Button(self.frame, text="Ingresar", command=self.login).pack(fill=tk.X, pady=20)
        ttk.Button(self.frame, text="Crear cuenta de Comprador", command=self.mostrar_registro).pack(fill=tk.X)

    def login(self):
        rut = self.entry_user.get().strip()
        pwd = self.entry_pass.get()
        usuario = self.controller.autenticar_usuario(rut, pwd)
        
        if usuario:
            self.frame.destroy()
            self.on_login_success(usuario)
        else:
            messagebox.showerror("Error", "Usuario o contraseña incorrectos")

    def mostrar_registro(self):
        self.on_show_registro()

class RegistroWindow:
    def __init__(self, root, controller: SupermercadoController, on_volver_login, on_registro_exitoso):
        self.root = root
        self.controller = controller
        self.on_volver_login = on_volver_login
        self.on_registro_exitoso = on_registro_exitoso
        
        self.frame = ttk.Frame(root, padding="20")
        self.frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(self.frame, text="Nuevo Usuario", font=('Helvetica', 14, 'bold')).pack(pady=20)
        
        ttk.Label(self.frame, text="RUT:").pack(anchor=tk.W)
        self.entry_user = ttk.Entry(self.frame)
        self.entry_user.pack(fill=tk.X, pady=5)

        ttk.Label(self.frame, text="Nombre:").pack(anchor=tk.W)
        self.entry_nombre = ttk.Entry(self.frame)
        self.entry_nombre.pack(fill=tk.X, pady=5)
        
        ttk.Label(self.frame, text="Contraseña:").pack(anchor=tk.W)
        self.entry_pass = ttk.Entry(self.frame, show="*")
        self.entry_pass.pack(fill=tk.X, pady=5)
        
        btn_frame = ttk.Frame(self.frame)
        btn_frame.pack(fill=tk.X, pady=20)
        
        ttk.Button(btn_frame, text="Registrar", command=self.registrar).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
        ttk.Button(btn_frame, text="Volver", command=self.volver).pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(5, 0))

    def volver(self):
        self.frame.destroy()
        self.on_volver_login()

    def registrar(self):
        rut = self.entry_user.get().strip()
        nombre = self.entry_nombre.get().strip()
        pwd = self.entry_pass.get()

        if not rut or not pwd:
            messagebox.showwarning("Aviso", "Complete RUT y contraseña")
            return

        try:
            ok = self.controller.registrar_usuario(rut, pwd, nombre, 'comprador')
            if ok:
                messagebox.showinfo("Éxito", "Usuario registrado. Ahora puede iniciar sesión.")
                self.frame.destroy()
                self.on_registro_exitoso()
            else:
                messagebox.showerror("Error", "El RUT ya existe")
        except ValueError as ve:
            messagebox.showerror("Error de validación", str(ve))
