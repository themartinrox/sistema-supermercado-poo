"""Punto de entrada principal de la aplicación (Script de inicio).

Este archivo:
1. Inicializa la ventana principal de Tkinter
2. Configura rutas absolutas para los archivos JSON (evita duplicados)
3. Crea el controlador principal (fachada)
4. Gestiona la navegación entre ventanas (login, registro, principal)

Ejecución: python main.py
"""

import os
import tkinter as tk
from controllers.supermercado_controller import SupermercadoController
from views.gui import LoginWindow, SupermercadoGUI, RegistroWindow
from models.usuario import Usuario

class Application:
    """
    Clase principal de la aplicación que gestiona el flujo de ventanas y controla la navegación.
    
    Responsabilidades:
    - Inicializar la ventana principal
    - Crear el controlador del supermercado
    - Cambiar entre ventanas (login, registro, interfaz principal)
    - Pasar información de usuario entre ventanas
    """
    
    def __init__(self, root):
        """Inicializa la aplicación.
        
        Parámetro:
            root: ventana principal de Tkinter
        """
        self.root = root
        self.root.title("Sistema de Supermercado")
        self.root.geometry("400x350")
        
        # IMPORTANTE: Usar rutas ABSOLUTAS basadas en la ubicación de este archivo.
        # Esto evita el problema de tener JSON guardados en dos lugares diferentes
        # (lo que ocurría cuando ejecutabas `python main.py` desde otro directorio).
        # 
        # Ejemplo:
        # - Si ejecutas: python main.py
        #   Se guarda en:  (carpeta donde está main.py)/data/usuarios.json
        # - Si ejecutas: cd .. ; python sistema-supermercado-poo-main/main.py
        #   Se guarda en:  (carpeta donde está main.py)/data/usuarios.json
        # En ambos casos es el MISMO lugar, gracias a __file__
        
        base_dir = os.path.dirname(__file__)  # Carpeta donde está este archivo (main.py)
        path_productos = os.path.join(base_dir, 'data', 'productos.json')
        path_ventas = os.path.join(base_dir, 'data', 'ventas.json')
        path_usuarios = os.path.join(base_dir, 'data', 'usuarios.json')

        # Inicializa el controlador principal (fachada de SupermercadoController)
        # que orquesta la lógica del negocio y coordina los tres sub-controladores
        self.controller = SupermercadoController(
            archivo_productos=path_productos,
            archivo_ventas=path_ventas,
            archivo_usuarios=path_usuarios
        )
        
        # Mostrar la ventana de inicio de sesión al arrancar la aplicación
        self.show_login_window()

    def show_login_window(self):
        """Muestra la ventana de inicio de sesión (LoginWindow).
        
        Se llama:
        - Al iniciar la aplicación
        - Cuando el usuario cierra sesión
        - Cuando cancela registro
        """
        # Limpiar widgets de la ventana anterior
        self._clear_widgets()
        self.root.title("Inicio de Sesión - Supermercado")
        self.root.geometry("400x350")
        # Crear ventana de login con callbacks para navegar
        self.login_view = LoginWindow(
            self.root, 
            self.controller, 
            self.on_login_success,  # Callback si login es exitoso
            self.show_registro_window  # Callback si usuario quiere registrarse
        )

    def show_registro_window(self):
        """Muestra la ventana de registro de nuevos usuarios (RegistroWindow).
        
        Se llama cuando el usuario hace clic en "Registrarse" en el login.
        """
        # Limpiar widgets de la ventana anterior (login)
        self._clear_widgets()
        self.root.title("Registro de Usuario - Supermercado")
        self.root.geometry("400x400")
        # Crear ventana de registro con callbacks para navegar
        self.registro_view = RegistroWindow(
            self.root, 
            self.controller,
            self.show_login_window,  # Callback si registro exitoso (volver a login)
            self.show_login_window   # Callback si usuario cancela (volver a login)
        )

    def on_login_success(self, usuario: Usuario):
        """Callback ejecutado cuando el login es exitoso.
        
        Carga la interfaz principal del supermercado y muestra datos del usuario en el título.
        
        Parámetro:
            usuario: objeto Usuario autenticado
        """
        # Limpiar widgets de la ventana anterior (login)
        self._clear_widgets()
        # Actualizar título con nombre y RUT del usuario logueado
        self.root.title(f"Supermercado - {usuario.nombre} ({usuario.rut})")
        # Ampliar ventana para la interfaz principal
        self.root.geometry("1024x768")
        # Crear interfaz principal, pasando la referencia para logout
        self.main_view = SupermercadoGUI(
            self.root, 
            usuario, 
            self.controller, 
            self.on_logout  # Callback para cierre de sesión
        )

    def on_logout(self):
        """Callback para cerrar sesión y volver a la pantalla de login.
        
        Se llama cuando el usuario hace clic en "Cerrar Sesión"
        en la interfaz principal.
        """
        # Mostrar pantalla de login nuevamente
        self._clear_widgets()
        self.show_login_window()

    def _clear_widgets(self):
        """Elimina todos los widgets de la ventana para limpiar antes de cambiar de vista.
        
        Esto permite que la ventana se reutilice para diferentes interfaces (login, registro, principal).
        """
        for widget in self.root.winfo_children():
            widget.destroy()

def main():
    """Función principal que crea la ventana y ejecuta el loop de eventos."""
    root = tk.Tk()
    app = Application(root)
    # Iniciar el event loop de Tkinter (la aplicación se mantiene en ejecución aquí)
    root.mainloop()

if __name__ == "__main__":
    # Punto de entrada: ejecutar main() si este archivo se corre directamente
    main()
