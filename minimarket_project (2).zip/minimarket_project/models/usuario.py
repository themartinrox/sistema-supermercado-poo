import json

class Usuario:
    def __init__(self, usuario, password, rol):
        self.usuario = usuario
        self.password = password
        self.rol = rol  # "admin" o "vendedor"

class UsuariosDB:
    def __init__(self, ruta="data/trabajadores.json"):
        self.ruta = ruta
        self.usuarios = self.cargar()

    def cargar(self):
        try:
            with open(self.ruta, "r", encoding="utf-8") as f:
                datos = json.load(f)
                return [Usuario(**u) for u in datos]
        except:
            return []

    def validar(self, usuario, password):
        for u in self.usuarios:
            if u.usuario == usuario and u.password == password:
                return u
        return None
