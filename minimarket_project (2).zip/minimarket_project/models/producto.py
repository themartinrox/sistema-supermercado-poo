class Producto:
    def __init__(self, nombre, precio, tipo, stock):
        self.nombre = nombre
        self.precio = precio  # CLP entero
        self.tipo = tipo      # "unidad" o "kilo"
        self.stock = stock    # entero o kg

    def to_dict(self):
        return {
            "nombre": self.nombre,
            "precio": self.precio,
            "tipo": self.tipo,
            "stock": self.stock
        }
