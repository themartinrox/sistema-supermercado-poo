import json
from datetime import datetime

class RegistroVentas:
    def __init__(self, ruta="data/ventas.json"):
        self.ruta = ruta

    def registrar(self, producto, cantidad, total):
        venta = {
            "producto": producto,
            "cantidad": cantidad,
            "total": total,
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        try:
            with open(self.ruta, "r", encoding="utf-8") as f:
                datos = json.load(f)
        except:
            datos = []

        datos.append(venta)
        with open(self.ruta, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=4, ensure_ascii=False)
