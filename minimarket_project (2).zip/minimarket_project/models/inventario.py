import json
from models.producto import Producto

class Inventario:
    def __init__(self, ruta="data/inventario.json"):
        self.ruta = ruta
        self.productos = self.cargar()

    def cargar(self):
        try:
            with open(self.ruta, "r", encoding="utf-8") as f:
                datos = json.load(f)
                return [Producto(**p) for p in datos]
        except:
            return []

    def guardar(self):
        with open(self.ruta, "w", encoding="utf-8") as f:
            json.dump([p.to_dict() for p in self.productos], f, indent=4, ensure_ascii=False)

    def agregar_producto(self, producto):
        self.productos.append(producto)
        self.guardar()

    def buscar(self, nombre):
        for p in self.productos:
            if p.nombre.lower() == nombre.lower():
                return p
        return None
