import tkinter as tk


class HomeView(tk.Frame):
    def __init__(self, root, app, usuario):
        super().__init__(root)
        self.app = app
        self.usuario = usuario

        tk.Label(self, text=f"Bienvenido {usuario.usuario} | Rol: {usuario.rol}").pack(pady=10)

        if usuario.rol == "admin":
            tk.Button(self, text="Inventario", command=self.ir_inventario).pack(pady=5)

        tk.Button(self, text="Ventas", command=self.ir_ventas).pack(pady=5)
        tk.Button(self, text="Cerrar sesión", command=self.cerrar_sesion).pack(pady=20)

    def ir_inventario(self):
        from views.inventario_view import InventarioView
        self.app.cambiar_frame(InventarioView)

    def ir_ventas(self):
        from views.ventas_view import VentasView
        self.app.cambiar_frame(VentasView)

    def cerrar_sesion(self):
        from views.login_view import LoginView
        self.app.cambiar_frame(LoginView)
