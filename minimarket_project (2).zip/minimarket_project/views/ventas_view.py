import tkinter as tk
from controllers.ventas_controller import VentasController

class VentasView(tk.Frame):
    def __init__(self, root, app):
        super().__init__(root)
        self.controller = VentasController()

        tk.Label(self, text="Ventas").pack(pady=10)

        self.nombre = tk.Entry(self); tk.Label(self, text="Producto").pack(); self.nombre.pack()
        self.cantidad = tk.Entry(self); tk.Label(self, text="Cantidad").pack(); self.cantidad.pack()

        tk.Button(self, text="Vender", command=self.vender).pack(pady=10)
        self.msg = tk.Label(self, text="", fg="blue")
        self.msg.pack()

    def vender(self):
        try:
            nombre = self.nombre.get()
            cantidad = int(self.cantidad.get())

            ok, respuesta = self.controller.vender(nombre, cantidad)
            if ok:
                self.msg.config(text=f"Venta realizada. Total: {respuesta} CLP", fg="blue")
            else:
                self.msg.config(text=respuesta, fg="red")
        except Exception as e:
            self.msg.config(text=f"Error: {e}", fg="red")
