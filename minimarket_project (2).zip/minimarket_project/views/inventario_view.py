import tkinter as tk
from controllers.inventario_controller import InventarioController

class InventarioView(tk.Frame):
    def __init__(self, root, app):
        super().__init__(root)
        self.controller = InventarioController()

        tk.Label(self, text="Agregar Producto").pack(pady=10)

        self.nombre = tk.Entry(self); tk.Label(self, text="Nombre").pack(); self.nombre.pack()
        self.precio = tk.Entry(self); tk.Label(self, text="Precio CLP").pack(); self.precio.pack()
        self.tipo = tk.Entry(self); tk.Label(self, text="Tipo (unidad/kilo)").pack(); self.tipo.pack()
        self.stock = tk.Entry(self); tk.Label(self, text="Stock").pack(); self.stock.pack()

        tk.Button(self, text="Guardar", command=self.guardar).pack(pady=10)
        self.msg = tk.Label(self, text="", fg="green")
        self.msg.pack()

    def guardar(self):
        try:
            nombre = self.nombre.get()
            precio = int(self.precio.get())
            tipo = self.tipo.get()
            stock = int(self.stock.get())

            self.controller.agregar_producto(nombre, precio, tipo, stock)
            self.msg.config(text="Producto agregado correctamente")
        except Exception as e:
            self.msg.config(text=f"Error: {e}", fg="red")
