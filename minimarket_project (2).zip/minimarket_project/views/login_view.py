import tkinter as tk

class LoginView(tk.Frame):
    def __init__(self, root, app):
        super().__init__(root)
        self.app = app

        tk.Label(self, text="Usuario:").pack()
        self.usuario = tk.Entry(self)
        self.usuario.pack()

        tk.Label(self, text="Contraseña:").pack()
        self.password = tk.Entry(self, show="*")
        self.password.pack()

        tk.Button(self, text="Ingresar", command=self.login).pack(pady=10)
        self.msg = tk.Label(self, text="", fg="red")
        self.msg.pack()

    def login(self):
        u = self.usuario.get()
        p = self.password.get()

        ok, usuario = self.app.auth.login(u, p)
        if ok:
            # Import here to avoid circular import at module import time
            from views.home_view import HomeView
            self.app.cambiar_frame(HomeView, usuario=usuario)
        else:
            self.msg.config(text="Credenciales incorrectas")
