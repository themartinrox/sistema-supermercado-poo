from models.inventario import Inventario
from models.venta import RegistroVentas

class VentasController:
    def __init__(self):
        self.inventario = Inventario()
        self.registro = RegistroVentas()

    def vender(self, nombre, cantidad):
        producto = self.inventario.buscar(nombre)
        if not producto:
            return False, "Producto no existe"

        if producto.stock < cantidad:
            return False, "Stock insuficiente"

        total = producto.precio * cantidad
        producto.stock -= cantidad

        self.inventario.guardar()
        self.registro.registrar(nombre, cantidad, total)

        return True, total
