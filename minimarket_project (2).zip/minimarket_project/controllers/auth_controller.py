from models.usuario import UsuariosDB

class AuthController:
    def __init__(self):
        self.db = UsuariosDB()
        self.usuario_actual = None

    def login(self, usuario, password):
        user = self.db.validar(usuario, password)
        if user:
            self.usuario_actual = user
            return True, user
        return False, None
