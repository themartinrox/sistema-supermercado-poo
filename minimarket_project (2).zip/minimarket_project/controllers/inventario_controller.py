from models.inventario import Inventario
from models.producto import Producto

class InventarioController:
    def __init__(self):
        self.inventario = Inventario()

    def agregar_producto(self, nombre, precio, tipo, stock):
        producto = Producto(nombre, precio, tipo, stock)
        self.inventario.agregar_producto(producto)
        return True
