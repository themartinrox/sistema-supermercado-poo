from app import MinimarketApp

if __name__ == "__main__":
    app = MinimarketApp()
    app.run()
