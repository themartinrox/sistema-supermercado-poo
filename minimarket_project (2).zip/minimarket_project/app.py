import tkinter as tk
from views.login_view import LoginView
from controllers.auth_controller import AuthController

class MinimarketApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Minimarket - Sistema")
        self.root.geometry("900x600")

        self.auth = AuthController()

        self.actual_frame = None
        self.cambiar_frame(LoginView)

    def cambiar_frame(self, frame_class, **kwargs):
        if self.actual_frame:
            self.actual_frame.destroy()
        self.actual_frame = frame_class(self.root, self, **kwargs)
        self.actual_frame.pack(fill="both", expand=True)

    def run(self):
        self.root.mainloop()
